<html> 
<head> 
    <meta http-equiv="content-type" content="text/html;charset=ISO-8859-1"> 
    <title>Gestione di AVconv - scrittura parametri</title>   
    <link href="stile.css" rel="stylesheet" type="text/css">
</head> 

<body  onLoad="setTimeout('goBack()', 3000)"> 
<table style="border:1px blue" border="1" >
<tr><td>
<h1>Parametri memorizzati</h1>
<?php

 $abit = $_GET['abit'];
 $vbit = $_GET['vbit'];
 $fps  = $_GET['fps'];
 $qual = $_GET['qual'];
 $ver  = $_GET['ver'];
// $sub = $_GET['sub'];
 if(isset($_GET['sub']) && $_GET['sub']!=""):
  $sub = $_GET['sub'];
 else:
  $sub='off';
 endif;
 
 #$qual = strip_tags($qual);
 #$ver = strip_tags($ver);

 $qual = str_replace(array("\n", "\r"), '', $qual ); 
 $ver = str_replace(array("\n", "\r"), '', $ver );
 $sub = str_replace(array("\n", "\r"), '', $sub );

 echo "Video bitrate: $vbit </br>";
 echo "Audio bitrate: $abit </br>";
 echo "Frame per sec: $fps </br>";
 echo "Qualita'     : $qual</br>";
 echo "Sottocartelle: $sub</br>";
	
 $file = fopen("/vconv/parametri.txt", "w");
 fwrite($file,$ver . PHP_EOL  );
 fwrite($file,$vbit. PHP_EOL );
 fwrite($file,$abit. PHP_EOL);
 fwrite($file,$fps . PHP_EOL);
 fwrite($file,$qual. PHP_EOL );
 fwrite($file,$sub . PHP_EOL );
 fclose($file);
?>


</td></tr>

<tr><td>
<center>

<button onclick="goBack()">Go Back</button>

<script>
 function goBack() {
    window.history.back();
 }
</script>
<br>
(Torno indietro automaticamente in 3 secondi)
</center>

</td></tr>

</table>


</body> 
</html>

